#!usr/bin/env python3

def greet():
    print('Hello!')
    return

